<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div x-data="{
    updateGradeModal:false,
    confirmModal:false,
    deleteEnrollmentModal:false,
    selectedEnrollmentId:null,
    selectedEnrolledSubjectId:null,
    selectedGrade: '',
    selectedRemarks:'',
    }"
>
    <div>
        <h1>Enrollment Records</h1>
        <?php if($student->middle_name): ?>
        <h2>Student: <?php echo e($student->first_name .' '.substr($student->middle_name,0,1).' '.$student->last_name); ?></h2>
        <?php else: ?>
        <h2>Student: <?php echo e($student->first_name .' '.$student->last_name); ?></h2>
        <?php endif; ?>
        <h2>Student Number: <?php echo e($student->student_number); ?></h2>
        <div>
            <?php $__currentLoopData = $groupedEnrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programId => $enrollments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $program = $enrollments->first()->program;
                    $enrollmentsByYear = $enrollments->groupBy('year_level');
                ?>
                <?php if($program->program_major): ?>
                <h3>Program: <?php echo e($program->program_name.' Major in '.$program->program_major); ?></h3>
                <?php else: ?>
                <h3>Program: <?php echo e($program->program_name); ?></h3>
                <?php endif; ?>
                <?php $__currentLoopData = $enrollmentsByYear; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $enrollmentsByTerm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h4>Year Level: <?php echo e($year); ?></h4>
                    <?php $__currentLoopData = $enrollmentsByTerm->groupBy('term'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term => $enrollments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('/gradeslip/pdf/print/' . $enrollment->enrollment_id)); ?>">Print Gradeslip</a>
                            <h5>Acad Year: <?php echo e($enrollment->academic_year); ?> - T<?php echo e($term); ?></h5>
                            <div>
                                <p>Enrollment Code: <?php echo e($enrollment->enrollment_code); ?></p>
                                <button @click="deleteEnrollmentModal=true; selectedEnrollmentId=<?php echo e($enrollment->enrollment_id); ?>">Delete Enrollment</button>
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Subject Code</th>
                                            <th>Subject Name</th>
                                            <th>Grade</th>
                                            <th>Remarks</th>
                                            <th>SecSubId</th>
                                            <th>Professor</th>
                                            <th>Enrolled Subject Code</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $enrollment->enrolledSubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrolledSubject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($enrolledSubject->subject->subject_code); ?></td>
                                                <td><?php echo e($enrolledSubject->subject->subject_name); ?></td>
                                                <td><?php echo e($enrolledSubject->final_grade ?? 'Not Graded'); ?></td>
                                                <td><?php echo e($enrolledSubject->remarks ?? 'No remarks'); ?></td>
                                                <td><?php echo e($enrolledSubject->sec_sub_id ?? 'No sec_sub'); ?></td>
                                                <td><?php echo e($enrolledSubject->sectionSubject->subjectSectionSchedule->professor->first_name ?? 'No professor record'); ?></td>
                                                <td><?php echo e($enrolledSubject->enrolledSubject_code ?? 'No enrolled subject code'); ?></td>
                                                <td>
                                                    <button @click=" 
                                                        updateGradeModal=true;
                                                        selectedEnrolledSubjectId= <?php echo e($enrolledSubject->en_subjects_id); ?>;
                                                        selectedGrade= '<?php echo e($enrolledSubject->final_grade); ?>';
                                                        selectedRemarks= '<?php echo e($enrolledSubject->remarks); ?>';
                                                        selectedEnrollmentId=<?php echo e($enrolledSubject->enrollment_id); ?>;">
                                                        Update Grade
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- Update grade modal -->
    <div x-cloak x-show="updateGradeModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center px-4 z-50">
        <div class="modal-content bg-white p-8 rounded-lg shadow-lg overflow-auto max-w-lg w-full min-h-[35vh] max-h-[35vh]">
            <h3>Update Grade</h3>
            <form :action="'/admin/enrollment-records/' + selectedEnrollmentId + '/' + selectedEnrolledSubjectId" method="POST" class="space-y-4">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <input type="hidden" name="email" value="<?php echo e($user->email); ?>">
                <div>
                    <label for="grade" class="block text-sm font-medium text-gray-700">Grade:</label>
                    <input type="number" id="grade" name="grade" step="0.01" min="0" x-model="selectedGrade" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                </div>
                <div class="mb-4">
                    <label for="remarks" class="block text-sm font-medium text-gray-700">Enter remarks:</label>
                    <input type="text" id="remarks" name="remarks" x-model="selectedRemarks" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                </div>
                <div class="mb-4">
                    <label for="password" class="block text-sm font-medium text-gray-700">Enter Password (Admin):</label>
                    <input type="password" id="password" name="password" @paste.prevent="" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                </div>
                <div class="flex justify-end space-x-4">
                    <button type="button" @click="updateGradeModal=false" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 transition ease-in-out duration-150">Cancel</button>
                    <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition ease-in-out duration-150">Update Grade</button>
                </div>
            </form>
        </div>
    </div>
    <!-- Delete Enrollment Modal -->
    <div x-cloak x-show="deleteEnrollmentModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center px-4 z-50">
        <div class="modal-content bg-white p-8 rounded-lg shadow-lg overflow-auto max-w-lg w-full min-h-[35vh] max-h-[35vh]">
            <h3>Delete Enrollment</h3>
            <p class="text-red-500">Warning: Deleted records cannot be retrieved. Continue?</p>
            <form :action="'/admin/faculty-records/delete/' + selectedEnrollmentId" method="POST" class="space-y-4">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="hidden" name="email" value="<?php echo e($user->email); ?>">
                <div class="mb-4">
                    <label for="password" class="block text-sm font-medium text-gray-700">Enter Password (Admin):</label>
                    <input type="password" name="password" @paste.prevent="" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                </div>
                <div class="flex justify-end space-x-4">
                    <button type="button" @click="deleteEnrollmentModal=false" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 transition ease-in-out duration-150">Cancel</button>
                    <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition ease-in-out duration-150">Confirm Delete</button>
                </div>
            </form>
        </div>
    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views/admin/enrollment-records-show.blade.php ENDPATH**/ ?>