
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Gradeslip</title>
    <style>
        body {
            font-family: 'Georgia', 'Arial', sans-serif;
            padding: 20px;
        }
        .gradeslip-container {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        .header {
            text-align: center;
            position: relative;
        }
        .info-logo {
            width: 7rem;
            position: absolute;
            top: 0;
            left: 0;
        }
    </style>
</head>
<body>
    <div class="gradeslip-container">
        <div class="header">
            <p>Informatics College Northgate Inc.</p>
            <p>Cyberzone Filinvest, Indo China Drive, Corporate Ave.</p>
            <p>Alabang, Muntinlupa, Metro Manila</p>
            <p>Gradeslip</p>
            <!-- <h3>Gradeslip for <?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></h3> -->
        </div>
        <div>
            <p>Name: <?php echo e($student_name); ?></p>
            <p>Student No: <?php echo e($student->student_number); ?></p>
            <p>Academic Year: <?php echo e($enrollment->academic_year); ?></p>
            <p>Term: <?php echo e($enrollment->term); ?></p>
            <p>Program: <?php echo e($enrollment->program->program_code); ?></p>
            <p>Year Level: <?php echo e($enrollment->year_level); ?></p>
            <p>Enrollment Code: <?php echo e($enrollment->enrollment_code); ?></p>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Subject Code</th>
                    <th>Subject Description</th>
                    <th>Total Units</th>
                    <th>Grade</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $enrolledSubjectsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($data['subject_code']); ?></td>
                    <td><?php echo e($data['subject_name']); ?></td>
                    <td><?php echo e($data['total_units']); ?></td>
                    <td><?php echo e($data['final_grade']); ?></td>
                    <td><?php echo e($data['remarks'] ?? 'No remarks'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views/admin/printable_templates/gradeslip-template.blade.php ENDPATH**/ ?>