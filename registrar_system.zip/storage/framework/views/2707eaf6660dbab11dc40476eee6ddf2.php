<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="stu-records py-6 max-h-full">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8" >
            <div class="flex overflow-hidden lg:min-h-[87h] md:min-h-[80vh] sm:min-h-[73vh]">
            <!-- Sidebar / Navigation -->
            <aside class="w-1/5 lg:min-h-[87h] md:min-h-[80vh] sm:min-h-[73vh] sm:rounded-lg bg-white shadow p-4">
                <nav class="registrar-functions-nav">
                    <ul class="mt-4">
                        <li class="menu-nav" @click.prevent="openStudents = !openStudents">
                            <a href="<?php echo e(route('student-records')); ?>" class="<?php echo e(request()->routeIs('student-records') || request()->routeIs('student.add') ? 'font-semibold' : ''); ?> block rounded-md py-2 px-4 hover:bg-gray-200">
                            Student Records
                            </a>
                        </li>
                        <li>
                            <ul x-show="openStudents" class="submenu">
                                <li>
                                    <a href="<?php echo e(route('student-records')); ?>" class="<?php echo e(request()->routeIs('student-records') ? 'active-main' : ''); ?> block rounded-md py-2 hover:bg-gray-200">
                                        Student Records
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('student.add')); ?>" class="<?php echo e(request()->routeIs('student.add') ? 'active-main' : ''); ?> block rounded-md py-2 px-6 hover:bg-gray-200">
                                        Add Student
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu-nav">
                            <a href="<?php echo e(route('faculty-records')); ?>" class="<?php echo e(request()->routeIs('faculty-records') ? 'active-main' : ''); ?> block rounded-md py-2 px-4 hover:bg-gray-200">
                                Faculty Records
                            </a>
                        </li>
                    </ul>
                </nav>
            </aside>


                <!-- Main Content Area -->
                <main class="w-4/5 bg-white shadow overflow-hidden sm:rounded-lg p-6 ml-4">
                    <!-- Main content goes here -->
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            </div>
        </div>
    </div>
        
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views/admin/records.blade.php ENDPATH**/ ?>