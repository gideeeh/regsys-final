<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transcript of Records</title>
    <style>
        @media (min-width: 1024px) { /* Large screens */
            .stu-academic-info {
                min-height: 45vh;
            }
        }
        @media (min-width: 768px) { /* Medium screens */
            .stu-academic-info {
                min-height: 38vh;
            }
        }
        @media (min-width: 640px) { /* Small screens */
            .stu-academic-info {
                min-height: 31vh;
            }
        }
    </style>
</head>
<body>
    <h1>TOR Template for <?php echo e($program->program_name); ?></h1>
    <div class="stu-academic-info" style="margin-top: 1rem; background-color: white; border: 1px solid; border-radius: 0.5rem; padding: 1.5rem; gap: 1rem; cursor: default;">
        <h3 style="display: flex; width: 100%; justify-content: center; background-color: #0ea5e9; padding: 0.5rem; border-radius: 0.375rem; color: white; margin-bottom: 1rem;">Academic History</h3>
        <!-- Start directly with year levels and terms since we're focusing on a single program -->
        <?php $__currentLoopData = $organizedEnrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearLevel => $terms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <strong><?php echo e($yearLevel); ?> Year</strong>
                <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term => $subjects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p>Term <?php echo e($term); ?></p>
                    <table style="min-width: 100%; table-layout: auto;">
                        <thead>
                            <tr>
                                <th style="border: 1px solid; padding: 0.5rem;">Subject Code</th>
                                <th style="border: 1px solid; padding: 0.5rem;">Subject Name</th>
                                <th style="border: 1px solid; padding: 0.5rem;">Grade</th>
                                <th style="border: 1px solid; padding: 0.5rem;">Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrolledSubject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="border: 1px solid; padding: 0.5rem;"><?php echo e($enrolledSubject->subject->subject_code); ?></td>
                                    <td style="border: 1px solid; padding: 0.5rem;"><?php echo e($enrolledSubject->subject->subject_name); ?></td>
                                    <td style="border: 1px solid; padding: 0.5rem;"><?php echo e($enrolledSubject->final_grade ?? 'Not Graded'); ?></td>
                                    <td style="border: 1px solid; padding: 0.5rem;"><?php echo e($enrolledSubject->remarks ?? 'No Remarks'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views/admin/printable_templates/tor-template.blade.php ENDPATH**/ ?>