
<?php $__env->startSection('content'); ?>
<div x-data="{ searchTerm: '<?php echo e($searchTerm ?? ''); ?>' }">
    <div class="flex justify-between items-center h-10">
        <a href="<?php echo e(route('enrollment-records')); ?>" class="text-2xl font-semibold mb-4text-gray-800 leading-tight no-underline hover:underline">
            <?php echo e(__('Enrollment Records')); ?>

        </a>
        <?php if (isset($component)) { $__componentOriginale48b4598ffc2f41a085f001458a956d1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale48b4598ffc2f41a085f001458a956d1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search-form','data' => ['action' => ''.e(route('enrollment-records')).'','placeholder' => 'Search Enrollment']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('enrollment-records')).'','placeholder' => 'Search Enrollment']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale48b4598ffc2f41a085f001458a956d1)): ?>
<?php $attributes = $__attributesOriginale48b4598ffc2f41a085f001458a956d1; ?>
<?php unset($__attributesOriginale48b4598ffc2f41a085f001458a956d1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale48b4598ffc2f41a085f001458a956d1)): ?>
<?php $component = $__componentOriginale48b4598ffc2f41a085f001458a956d1; ?>
<?php unset($__componentOriginale48b4598ffc2f41a085f001458a956d1); ?>
<?php endif; ?>
    </div>

    <div class="py-4">
        <div class="my-4">
            <?php echo e($students->links()); ?>

        </div>
        <div class="py-4">
            <div class="overflow-x-auto bg-white rounded-lg shadow overflow-y-auto relative">   
                <table class="border-collapse table-auto w-full whitespace-no-wrap bg-white table-striped relative">
                    <thead >
                        <tr class="cursor-default text-left text-sm">
                            <th class="bg-blue-500 text-white p-1 pl-4 w-2/12">Student Number</th>
                            <th class="bg-blue-500 text-white p-1 w-3/12">Name</th>
                            <th class="bg-blue-500 text-white p-1 w-3/12">Program</th>
                            <th class="bg-blue-500 text-white p-1 w-2/12">Year Level</th>
                            <!-- <th class="bg-blue-500 text-white p-1 pr-4 w-1/12 text-center">Actions</th> -->
                        </tr>
                    </thead>
                    <tbody>
                    <?php if($students->isNotEmpty()): ?>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-left text-sm border-b hover:bg-gray-100 cursor-pointer" x-data="{}" @click="window.location.href='<?php echo e(route('enrollment-records.show', $student->student_id)); ?>'">
                            <td class="border-dashed border-t border-gray-200 py-2 pl-4"><strong><?php echo e($student->student_number); ?></strong></td>
                            <td class="border-dashed border-t border-gray-200 p-1 py-2">
                                <?php echo e($student->first_name); ?> 
                                <?php echo e($student->middle_name ? substr($student->middle_name, 0, 1) . '. ' : ''); ?> 
                                <?php echo e($student->last_name); ?> <?php echo e($student->suffix ?? ''); ?>

                            </td>
                            <?php if(!$student->program_major): ?>
                            <td class="border-dashed border-t border-gray-200 p-1 py-2"><?php echo e($student->program_code ?? 'Not Available'); ?></td>
                            <?php else: ?>
                            <td class="border-dashed border-t border-gray-200 p-1 py-2"><?php echo e($student->program_code.' Major in '. ucfirst($student->program_major)  ?? 'Not Available'); ?></td>
                            <?php endif; ?>
                            <td class="border-dashed border-t border-gray-200 p-1 py-2"><?php echo e($student->year_level ?? '-'); ?></td>
                            <!-- <td class="border-dashed border-t border-gray-200 pr-4 py-2">
                                <div class="flex justify-between gap-1">
                                    <button onclick="event.stopPropagation(); window.open('<?php echo e(route('student.edit', $student->student_id)); ?>', '_blank');" class="bg-blue-500 text-sm text-white p-1 rounded hover:bg-blue-600">Update</button>
                                    <button @click.stop="deleteModal = true; selectedStudent = <?php echo e($student->student_id); ?>" class="bg-red-500 text-sm text-white p-1 rounded hover:bg-red-600 transition ease-in-out duration-150">Delete</button>
                                </div>
                            </td> -->
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" class="w-full mt-16 text-rose-600 text-center bg-slate-100 py-12">No Student Records Available</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.enrollments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views/admin/enrollment-records.blade.php ENDPATH**/ ?>