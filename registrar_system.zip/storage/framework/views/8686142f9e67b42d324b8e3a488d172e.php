
<?php $__env->startSection('content'); ?>
<div x-data="{searchTerm: '<?php echo e($searchTerm ?? ''); ?>'}">
    <div class="w-full bg-white shadow-sm sm:rounded-lg min-h-[80vh] p-6">
        <h3 class="flex w-full justify-center bg-sky-950 px-4 rounded-md text-white mb-6 cursor-default">Appointment Records</h3>
        <div class="flex justify-end items-center">
            <?php if (isset($component)) { $__componentOriginale48b4598ffc2f41a085f001458a956d1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale48b4598ffc2f41a085f001458a956d1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search-form','data' => ['action' => ''.e(route('appointments')).'','placeholder' => 'Search Appointment']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('appointments')).'','placeholder' => 'Search Appointment']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale48b4598ffc2f41a085f001458a956d1)): ?>
<?php $attributes = $__attributesOriginale48b4598ffc2f41a085f001458a956d1; ?>
<?php unset($__attributesOriginale48b4598ffc2f41a085f001458a956d1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale48b4598ffc2f41a085f001458a956d1)): ?>
<?php $component = $__componentOriginale48b4598ffc2f41a085f001458a956d1; ?>
<?php unset($__componentOriginale48b4598ffc2f41a085f001458a956d1); ?>
<?php endif; ?>
        </div>
        <div class="my-6">
            <?php echo e($appointments->links()); ?>

        </div>
        <div>
            <div class="overflow-x-auto bg-white rounded-lg shadow relative">
                <table class="border-collapse table-auto w-full whitespace-no-wrap bg-white table-striped relative">
                    <thead >
                        <tr class="cursor-default text-left text-sm">
                            <th class="bg-blue-500 text-white p-1 pl-4 w-2/12">Student Number</th>
                            <th class="bg-blue-500 text-white p-1 w-3/12">Name</th>
                            <th class="bg-blue-500 text-white p-1 w-2/12">Course & Year</th>
                            <th class="bg-blue-500 text-white p-1 w-2/12">Service Request</th>
                            <th class="bg-blue-500 text-white p-1 w-1/12">Status</th>
                            <th class="w-2/12 bg-blue-500 text-white p-1">Date of Request</th>
                            <!-- <th class="bg-blue-500 text-white p-2 w-3/12">Actions</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b hover:bg-gray-100 cursor-pointer text-sm" @click="window.location.href='<?php echo e(route('appointments.manage', $appointment->user_id)); ?>?highlight=<?php echo e($appointment->id); ?>'">
                            <td class="border-dashed border-t border-gray-200 pl-4 p-1 py-2"><?php echo e($appointment->student_number); ?></td>
                            <td class="border-dashed border-t border-gray-200 p-1 py-2"><?php echo e($appointment->student_first_name); ?> <?php echo e($appointment->student_last_name); ?></td>
                            <?php if($appointment->program_code && $appointment->year_level): ?>
                            <td class="border-dashed border-t border-gray-200 p-1 py-2"><?php echo e($appointment->program_code); ?> - <?php echo e($appointment->year_level); ?></td>
                            <?php else: ?>
                            <td class="border-dashed border-t border-gray-200 p-1 py-2">No record</td>
                            <?php endif; ?>                            
                            <td class="border-dashed border-t border-gray-200 p-1 py-2"><?php echo e($appointment->service_name); ?></td>
                            <td class="border-dashed border-t border-gray-200 p-1 py-2"><?php echo e(ucfirst($appointment->status)); ?></td>
                            <td class="border-dashed border-t border-gray-200 p-1 py-2"><?php echo e($appointment->created_at->format('M j, Y g:i A')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.appointments-partials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views/admin/appointments.blade.php ENDPATH**/ ?>