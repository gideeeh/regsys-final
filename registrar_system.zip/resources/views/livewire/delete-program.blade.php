<div>
    <p>Are you sure you want to delete this program?</p>
    <button wire:click="delete">Yes, Delete</button>
    <button wire:click="$emit('close-modal')">Cancel</button>
</div>