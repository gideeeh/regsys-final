<x-app-layout>
    <h1>Layout Tool Template</h1>
    <h1>TOR Prototype</h1>
    <table>
        <thead>
            <tr>
                <th>Course Code</th>
                <th>Course Description</th>
                <th>Acad Grade</th>
                <th>Credit Units</th>
                <th>Grade Point</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>-</td>
            </tr>
        </tbody>
    </table>
</x-app-layout>